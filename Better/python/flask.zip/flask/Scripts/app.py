from flask import Flask, render_template, redirect, url_for, session
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import DataRequired
from datetime import datetime
import random

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key'

class SignupForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Sign Up')

class SigninForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Sign In')

class ExamForm(FlaskForm):
    answer = StringField('Your Answer', validators=[DataRequired()])
    next_question = SubmitField('Next Question')

# Mock data for demonstration purposes
topics = ['Mathematics', 'Science', 'History', 'Geography', 'Programming']

questions = {
    'Mathematics': [
        {'question': 'What is 2 + 2?', 'answers': ['3', '4', '5', '6'], 'correct_answer': '4'},
        {'question': 'What is the square root of 16?', 'answers': ['2', '4', '8', '16'], 'correct_answer': '4'},
        # Add more math questions as needed
    ],
    'Science': [
        {'question': 'What is the chemical symbol for water?', 'answers': ['H2O', 'CO2', 'O2', 'NaCl'], 'correct_answer': 'H2O'},
        {'question': 'Which planet is known as the Red Planet?', 'answers': ['Earth', 'Mars', 'Jupiter', 'Saturn'], 'correct_answer': 'Mars'},
        # Add more science questions as needed
    ],
    'History': [
        {'question': 'Who was the first President of the United States?', 'answers': ['George Washington', 'Abraham Lincoln', 'Thomas Jefferson', 'John Adams'], 'correct_answer': 'George Washington'},
        {'question': 'In which year did World War II end?', 'answers': ['1918', '1945', '1960', '2000'], 'correct_answer': '1945'},
        # Add more history questions as needed
    ],
    'Geography': [
        {'question': 'What is the capital of France?', 'answers': ['London', 'Berlin', 'Paris', 'Rome'], 'correct_answer': 'Paris'},
        {'question': 'Which river is the longest in the world?', 'answers': ['Nile', 'Amazon', 'Yangtze', 'Mississippi'], 'correct_answer': 'Nile'},
        # Add more geography questions as needed
    ],
    'Programming': [
        {'question': 'What is the purpose of the "if" statement in programming?', 'answers': ['Iteration', 'Decision making', 'Function definition', 'Variable declaration'], 'correct_answer': 'Decision making'},
        {'question': 'Which programming language is known for its readability and simplicity?', 'answers': ['C', 'Java', 'Python', 'Ruby'], 'correct_answer': 'Python'},
        # Add more programming questions as needed
    ],
}

@app.route('/')
def index():
    current_time = datetime.now().strftime("%H:%M:%S")
    return render_template('index.html', current_time=current_time)

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    form = SignupForm()

    if form.validate_on_submit():
        # Handle signup logic (store user details, etc.)
        return redirect(url_for('index'))

    return render_template('signup.html', form=form)

@app.route('/signin', methods=['GET', 'POST'])
def signin():
    form = SigninForm()

    if form.validate_on_submit():
        # Handle signin logic (check user credentials, etc.)
        return redirect('/exam')  # Changed from url_for('exam_portal')

    return render_template('signin.html', form=form)

@app.route('/exam', methods=['GET', 'POST'])
def exam_portal():
    if 'topic' not in session or session['topic'] not in questions:
        # Choose a random topic for the user
        session['topic'] = random.choice(topics)
        session['question_number'] = 1
        session['score'] = 0

    current_topic = session['topic']

    if current_topic not in questions:
        # No questions available for the chosen topic
        return render_template('exam.html', topic=None)

    current_question_number = session['question_number']
    current_question = questions[current_topic][current_question_number]

    form = ExamForm()

    if form.validate_on_submit():
        # Check the submitted answer and update the score
        user_answer = form.answer.data
        correct_answer = current_question['correct_answer']

        if user_answer == correct_answer:
            session['score'] += 1

        # Move to the next question
        session['question_number'] += 1

        if session['question_number'] < len(questions[current_topic]):
            session['topic'] = None  # Reset the topic to None
            return redirect('/exam')  # Changed from url_for('exam_portal')
        else:
            return redirect(url_for('exam_result'))

    return render_template('exam.html', topic=current_topic, question=current_question, form=form)

@app.route('/exam/result')
def exam_result():
    final_score = session['score']
    # Clear session data after displaying the result
    session.pop('topic', None)
    session.pop('question_number', None)
    session.pop('score', None)

    return render_template('exam_result.html', final_score=final_score)

if __name__ == '__main__':
    app.run(debug=True)
